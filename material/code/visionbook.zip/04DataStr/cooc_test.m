% The matlabs graycomatrix.m function is not recommendable for testing our 
% cooc.m function since it contains errors. Propper functioning of cooc.m
% is to verify by inspection of the results of cooc_demo.m

