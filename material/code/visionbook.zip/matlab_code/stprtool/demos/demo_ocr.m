% DEMO_OCR Demo on Optical Character Recognition using SVM.
%
% Synopsis:
%  demo_ocr;
%
% Description:
%  For more information type 'help ocr'. 
%

% About: Statistical Pattern Recognition Toolbox
% (C) 1999-2003, Written by Vojtech Franc and Vaclav Hlavac
% <a href="http://www.cvut.cz">Czech Technical University Prague</a>
% <a href="http://www.feld.cvut.cz">Faculty of Electrical Engineering</a>
% <a href="http://cmp.felk.cvut.cz">Center for Machine Perception</a>

% Modifications:
% 20-sep-03, VF

open('demo_ocr.fig');

